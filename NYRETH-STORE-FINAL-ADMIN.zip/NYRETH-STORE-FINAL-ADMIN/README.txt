NYRETH-STORE ADMIN EDITION

Admin login:
Username: TAKARIOFFICIAL12
Password: ZOROMODZOLD1230

Admin features:
- Dashboard
- Edit product prices per duration
- Set each product Online / Maintenance
- Enable/disable payment methods
- Create/delete vouchers
- Theme setting
- Logout

Settings are stored in browser localStorage. This is a frontend prototype; for production security, move authentication and data to a backend/database.
